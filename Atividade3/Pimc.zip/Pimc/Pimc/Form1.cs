﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double Peso;
        double Altura;
        double Imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblPeso_Validated(object sender, EventArgs e)
        {

        }

        private void lblaltura_Validated(object sender, EventArgs e)
        {

        }

        private void lblImc_Validated(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {

        }

        private void textBox3_Validated(object sender, EventArgs e)
        {

        }

        private void textBox2_Validated(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Validated(object sender, EventArgs e)
        {

        }

        private void BtnLimpar_Validated(object sender, EventArgs e)
        {

        }

        private void BtnSair_Validated(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {


            if((!double.TryParse(mskbxPeso.Text,out Peso)) || (Peso <= 0))
            { 
                MessageBox.Show("Valores não aceitos");



            }
            
                    


           


        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxAltura.Text,out Altura)) || (Altura <= 0))
            {
                MessageBox.Show("Valores não aceitos");



            }



        }

        private void mskbxImc_Validated(object sender, EventArgs e)
        {
            
        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Imc = Peso/(Math.Pow(Altura, 2));
            txtImc.Text = Imc.ToString("n2");

            Imc = Math.Round(Imc, 1);

            if (Imc < 18.5)
                MessageBox.Show("Magreza - Grau 0");
            else if (Imc < 24.9)
                MessageBox.Show("Normal - Grau 0");
            else if (Imc < 29.9)
                MessageBox.Show("Sobrepeso - Grau 1");
            else if (Imc < 39.9)
                MessageBox.Show("Obesidade - Grau 2");
            else
                MessageBox.Show("Obesidade Grave - Grau 3");


            
            
            
        }

        private void txtImc_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
           Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
