﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            int[,] notas = new int[3, 5];

            string varaux = "";

            int totalcurso1 = 0, totalcurso2 = 0, totalcurso3 = 0, totalgeral = 0;

            string imprimir = "";

            for (var curso = 0; curso < 3; curso++)
            {
                for (var nota = 0; nota < 5; nota++)
                {
                    varaux = Interaction.InputBox("Digite as notas", "Entrada de notas");
                    if (!int.TryParse(varaux, out notas[curso, nota]))
                    {
                        MessageBox.Show("Nota Inválida (Apenas números inteiros positivos)");
                        nota--;
                    }
                    else
                    {
                        totalgeral += notas[curso, nota];

                        if (curso == 0)
                        {
                            totalcurso1 += notas[0, nota];
                        }
                        else if (curso == 1)
                        {
                            totalcurso2 += notas[1, nota];
                        }
                        else
                        {
                            totalcurso3 += notas[2, nota];
                        }
                    }

                }
            }

            for (int i = 0; i < 5; i++)
            {
                ListBox1.Items.Add("Total do curso 1 do Ano " + (i+1) + ": " + notas[0, i]);
            }
            ListBox1.Items.Add("");
            ListBox1.Items.Add("--------------------------------------------------------------------------------");
            ListBox1.Items.Add("Total curso 1: " + totalcurso1);
            ListBox1.Items.Add("");

            for (int i = 0; i < 5; i++)
            {
                ListBox1.Items.Add("Total do curso 2 do Ano " + (i + 1) + ": " + notas[1, i]);
            }
            ListBox1.Items.Add("");
            ListBox1.Items.Add("--------------------------------------------------------------------------------");
            ListBox1.Items.Add("Total curso 2: " + totalcurso2);
            ListBox1.Items.Add("");
            for (int i = 0; i < 5; i++)
            {
                ListBox1.Items.Add("Total do curso 3 do Ano " + (i + 1) + ": " + notas[2, i]); 
                    
            }
            ListBox1.Items.Add("");
            ListBox1.Items.Add("--------------------------------------------------------------------------------");
            ListBox1.Items.Add("Total curso 3: " + totalcurso3);
            ListBox1.Items.Add("");
            ListBox1.Items.Add("--------------------------------------------------------------------------------");
            ListBox1.Items.Add("Total Geral: " + totalgeral);


        }
           

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            ListBox1.Items.Clear();
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
