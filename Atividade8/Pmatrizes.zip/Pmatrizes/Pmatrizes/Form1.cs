﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i<20;i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }


            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio" };
            string aux = "";

            lista.Remove("Otávio");
            foreach (string x in lista)
            {
                aux = x +  "\n" + aux;
            }
            MessageBox.Show(aux);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            string varaux = "";
            double medias = 0;
            string imprimir = "";

            for(var aluno = 0; aluno<20;aluno++)
            {
                for(var nota=0;nota<3;nota++)
                {
                    varaux = Interaction.InputBox("Digite as notas", "Entrada de notas");

                    if (!double.TryParse(varaux, out notas[aluno,nota]))
                        {
                        MessageBox.Show("Nota inválida");
                        nota--;
                        }
                    else if (notas[aluno,nota] < 0 || notas[aluno,nota] > 10)
                    {
                        MessageBox.Show("As notas devem ser maiores que 0 e menores que 10");
                        nota--;
                    }
                    else
                    {
                        medias = medias + notas[aluno,nota];
                    }
                    
                }
                medias = medias / 3;
                imprimir = imprimir + "Aluno" + (aluno + 1) + " - Média: " + medias + "\n";
                medias = 0;
            }
            MessageBox.Show(imprimir);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj = new frmExercicio4();

            obj.Show();

            
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
